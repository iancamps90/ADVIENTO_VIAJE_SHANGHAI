# This file makes adeviento_web a Python package
