from enum import Enum


class Font(Enum):
    DEFAULT = "Inter, sans-serif"
    CHINESE = "Noto Sans SC, sans-serif"
    ACCENT = "Inter, sans-serif"
