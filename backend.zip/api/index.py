from adeviento_web.adeviento_web import app

# Para Vercel, necesitamos exportar la aplicación
handler = app.api
