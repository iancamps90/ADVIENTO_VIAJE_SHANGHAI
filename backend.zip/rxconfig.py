import reflex as rx

config = rx.Config(
    app_name="adeviento_web",
    backend_url="https://shanghai.iancamps.dev",
    db_url="sqlite:///reflex.db",
    env=rx.Env.PROD,
    disable_plugins=["reflex.plugins.sitemap.SitemapPlugin"],
)
